﻿namespace CTRspinoff
{
    partial class Choose_A_Character
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Choose_A_Character));
            this.textBox1 = new System.Windows.Forms.TextBox();
            this.cbbutton = new System.Windows.Forms.Button();
            this.ncbutton = new System.Windows.Forms.Button();
            this.crashbandicoot = new System.Windows.Forms.PictureBox();
            this.drneocortex = new System.Windows.Forms.PictureBox();
            this.backbutton2 = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.crashbandicoot)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.drneocortex)).BeginInit();
            this.SuspendLayout();
            // 
            // textBox1
            // 
            this.textBox1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(0)))));
            this.textBox1.Font = new System.Drawing.Font("Racer", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox1.Location = new System.Drawing.Point(117, 21);
            this.textBox1.Name = "textBox1";
            this.textBox1.Size = new System.Drawing.Size(530, 30);
            this.textBox1.TabIndex = 0;
            this.textBox1.Text = "Choose a character";
            this.textBox1.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // cbbutton
            // 
            this.cbbutton.Font = new System.Drawing.Font("Racer", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cbbutton.ForeColor = System.Drawing.Color.Blue;
            this.cbbutton.Location = new System.Drawing.Point(117, 119);
            this.cbbutton.Name = "cbbutton";
            this.cbbutton.Size = new System.Drawing.Size(530, 32);
            this.cbbutton.TabIndex = 1;
            this.cbbutton.Text = "Crash Bandicoot";
            this.cbbutton.UseVisualStyleBackColor = true;
            this.cbbutton.Click += new System.EventHandler(this.cbbutton_Click);
            // 
            // ncbutton
            // 
            this.ncbutton.Font = new System.Drawing.Font("Racer", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ncbutton.ForeColor = System.Drawing.Color.Red;
            this.ncbutton.Location = new System.Drawing.Point(117, 285);
            this.ncbutton.Name = "ncbutton";
            this.ncbutton.Size = new System.Drawing.Size(530, 32);
            this.ncbutton.TabIndex = 2;
            this.ncbutton.Text = "Dr. Neo Cortex";
            this.ncbutton.UseVisualStyleBackColor = true;
            this.ncbutton.Click += new System.EventHandler(this.ncbutton_Click);
            // 
            // crashbandicoot
            // 
            this.crashbandicoot.Image = ((System.Drawing.Image)(resources.GetObject("crashbandicoot.Image")));
            this.crashbandicoot.Location = new System.Drawing.Point(343, 197);
            this.crashbandicoot.Name = "crashbandicoot";
            this.crashbandicoot.Size = new System.Drawing.Size(72, 51);
            this.crashbandicoot.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.crashbandicoot.TabIndex = 3;
            this.crashbandicoot.TabStop = false;
            // 
            // drneocortex
            // 
            this.drneocortex.Image = ((System.Drawing.Image)(resources.GetObject("drneocortex.Image")));
            this.drneocortex.Location = new System.Drawing.Point(343, 344);
            this.drneocortex.Name = "drneocortex";
            this.drneocortex.Size = new System.Drawing.Size(72, 50);
            this.drneocortex.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.drneocortex.TabIndex = 4;
            this.drneocortex.TabStop = false;
            // 
            // backbutton2
            // 
            this.backbutton2.Font = new System.Drawing.Font("Racer", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.backbutton2.Location = new System.Drawing.Point(12, 398);
            this.backbutton2.Name = "backbutton2";
            this.backbutton2.Size = new System.Drawing.Size(313, 50);
            this.backbutton2.TabIndex = 5;
            this.backbutton2.Text = "Back to Main Menu";
            this.backbutton2.UseVisualStyleBackColor = true;
            this.backbutton2.Click += new System.EventHandler(this.backbutton2_Click);
            // 
            // Choose_A_Character
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(0)))));
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.backbutton2);
            this.Controls.Add(this.drneocortex);
            this.Controls.Add(this.crashbandicoot);
            this.Controls.Add(this.ncbutton);
            this.Controls.Add(this.cbbutton);
            this.Controls.Add(this.textBox1);
            this.Name = "Choose_A_Character";
            this.Text = "Choose_A_Character";
            ((System.ComponentModel.ISupportInitialize)(this.crashbandicoot)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.drneocortex)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox textBox1;
        private System.Windows.Forms.Button cbbutton;
        private System.Windows.Forms.Button ncbutton;
        private System.Windows.Forms.PictureBox crashbandicoot;
        private System.Windows.Forms.PictureBox drneocortex;
        private System.Windows.Forms.Button backbutton2;
    }
}
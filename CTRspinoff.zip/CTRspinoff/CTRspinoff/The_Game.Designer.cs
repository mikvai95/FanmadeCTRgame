﻿namespace CTRspinoff
{
    partial class The_Game
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(The_Game));
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.pictureBox2 = new System.Windows.Forms.PictureBox();
            this.pictureBox3 = new System.Windows.Forms.PictureBox();
            this.pictureBox4 = new System.Windows.Forms.PictureBox();
            this.pictureBox5 = new System.Windows.Forms.PictureBox();
            this.pictureBox6 = new System.Windows.Forms.PictureBox();
            this.timer1 = new System.Windows.Forms.Timer(this.components);
            this.crashbandicoot = new System.Windows.Forms.PictureBox();
            this.tntbox = new System.Windows.Forms.PictureBox();
            this.nitrobox = new System.Windows.Forms.PictureBox();
            this.beakerbox = new System.Windows.Forms.PictureBox();
            this.wumpacoin1 = new System.Windows.Forms.PictureBox();
            this.wumpacoin2 = new System.Windows.Forms.PictureBox();
            this.wumpacoin3 = new System.Windows.Forms.PictureBox();
            this.wumpacoinslabel = new System.Windows.Forms.Label();
            this.ohi = new System.Windows.Forms.Label();
            this.restartbutton = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox4)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox5)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox6)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.crashbandicoot)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tntbox)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.nitrobox)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.beakerbox)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.wumpacoin1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.wumpacoin2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.wumpacoin3)).BeginInit();
            this.SuspendLayout();
            // 
            // pictureBox1
            // 
            this.pictureBox1.BackColor = System.Drawing.Color.White;
            this.pictureBox1.Location = new System.Drawing.Point(220, -29);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(11, 72);
            this.pictureBox1.TabIndex = 0;
            this.pictureBox1.TabStop = false;
            this.pictureBox1.Click += new System.EventHandler(this.pictureBox1_Click);
            // 
            // pictureBox2
            // 
            this.pictureBox2.BackColor = System.Drawing.Color.White;
            this.pictureBox2.Location = new System.Drawing.Point(220, 63);
            this.pictureBox2.Name = "pictureBox2";
            this.pictureBox2.Size = new System.Drawing.Size(11, 72);
            this.pictureBox2.TabIndex = 1;
            this.pictureBox2.TabStop = false;
            // 
            // pictureBox3
            // 
            this.pictureBox3.BackColor = System.Drawing.Color.White;
            this.pictureBox3.Location = new System.Drawing.Point(220, 155);
            this.pictureBox3.Name = "pictureBox3";
            this.pictureBox3.Size = new System.Drawing.Size(11, 72);
            this.pictureBox3.TabIndex = 2;
            this.pictureBox3.TabStop = false;
            // 
            // pictureBox4
            // 
            this.pictureBox4.BackColor = System.Drawing.Color.White;
            this.pictureBox4.Location = new System.Drawing.Point(220, 248);
            this.pictureBox4.Name = "pictureBox4";
            this.pictureBox4.Size = new System.Drawing.Size(11, 72);
            this.pictureBox4.TabIndex = 3;
            this.pictureBox4.TabStop = false;
            // 
            // pictureBox5
            // 
            this.pictureBox5.BackColor = System.Drawing.Color.White;
            this.pictureBox5.Location = new System.Drawing.Point(220, 335);
            this.pictureBox5.Name = "pictureBox5";
            this.pictureBox5.Size = new System.Drawing.Size(11, 72);
            this.pictureBox5.TabIndex = 4;
            this.pictureBox5.TabStop = false;
            // 
            // pictureBox6
            // 
            this.pictureBox6.BackColor = System.Drawing.Color.White;
            this.pictureBox6.Location = new System.Drawing.Point(220, 422);
            this.pictureBox6.Name = "pictureBox6";
            this.pictureBox6.Size = new System.Drawing.Size(11, 72);
            this.pictureBox6.TabIndex = 5;
            this.pictureBox6.TabStop = false;
            // 
            // timer1
            // 
            this.timer1.Enabled = true;
            this.timer1.Interval = 10;
            this.timer1.Tick += new System.EventHandler(this.timer1_Tick);
            // 
            // crashbandicoot
            // 
            this.crashbandicoot.Image = ((System.Drawing.Image)(resources.GetObject("crashbandicoot.Image")));
            this.crashbandicoot.Location = new System.Drawing.Point(198, 394);
            this.crashbandicoot.Name = "crashbandicoot";
            this.crashbandicoot.Size = new System.Drawing.Size(52, 44);
            this.crashbandicoot.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.crashbandicoot.TabIndex = 6;
            this.crashbandicoot.TabStop = false;
            // 
            // tntbox
            // 
            this.tntbox.Image = ((System.Drawing.Image)(resources.GetObject("tntbox.Image")));
            this.tntbox.Location = new System.Drawing.Point(74, 310);
            this.tntbox.Name = "tntbox";
            this.tntbox.Size = new System.Drawing.Size(52, 45);
            this.tntbox.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.tntbox.TabIndex = 7;
            this.tntbox.TabStop = false;
            // 
            // nitrobox
            // 
            this.nitrobox.Image = ((System.Drawing.Image)(resources.GetObject("nitrobox.Image")));
            this.nitrobox.Location = new System.Drawing.Point(327, 184);
            this.nitrobox.Name = "nitrobox";
            this.nitrobox.Size = new System.Drawing.Size(51, 43);
            this.nitrobox.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.nitrobox.TabIndex = 8;
            this.nitrobox.TabStop = false;
            // 
            // beakerbox
            // 
            this.beakerbox.Image = ((System.Drawing.Image)(resources.GetObject("beakerbox.Image")));
            this.beakerbox.Location = new System.Drawing.Point(74, 76);
            this.beakerbox.Name = "beakerbox";
            this.beakerbox.Size = new System.Drawing.Size(28, 37);
            this.beakerbox.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.beakerbox.TabIndex = 9;
            this.beakerbox.TabStop = false;
            // 
            // wumpacoin1
            // 
            this.wumpacoin1.Image = ((System.Drawing.Image)(resources.GetObject("wumpacoin1.Image")));
            this.wumpacoin1.Location = new System.Drawing.Point(155, 333);
            this.wumpacoin1.Name = "wumpacoin1";
            this.wumpacoin1.Size = new System.Drawing.Size(25, 22);
            this.wumpacoin1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.wumpacoin1.TabIndex = 10;
            this.wumpacoin1.TabStop = false;
            // 
            // wumpacoin2
            // 
            this.wumpacoin2.Image = ((System.Drawing.Image)(resources.GetObject("wumpacoin2.Image")));
            this.wumpacoin2.Location = new System.Drawing.Point(254, 248);
            this.wumpacoin2.Name = "wumpacoin2";
            this.wumpacoin2.Size = new System.Drawing.Size(25, 22);
            this.wumpacoin2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.wumpacoin2.TabIndex = 11;
            this.wumpacoin2.TabStop = false;
            // 
            // wumpacoin3
            // 
            this.wumpacoin3.Image = ((System.Drawing.Image)(resources.GetObject("wumpacoin3.Image")));
            this.wumpacoin3.Location = new System.Drawing.Point(172, 205);
            this.wumpacoin3.Name = "wumpacoin3";
            this.wumpacoin3.Size = new System.Drawing.Size(25, 22);
            this.wumpacoin3.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.wumpacoin3.TabIndex = 12;
            this.wumpacoin3.TabStop = false;
            // 
            // wumpacoinslabel
            // 
            this.wumpacoinslabel.AutoSize = true;
            this.wumpacoinslabel.Font = new System.Drawing.Font("Comic Sans MS", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.wumpacoinslabel.ForeColor = System.Drawing.Color.Yellow;
            this.wumpacoinslabel.Location = new System.Drawing.Point(58, 32);
            this.wumpacoinslabel.Name = "wumpacoinslabel";
            this.wumpacoinslabel.Size = new System.Drawing.Size(20, 23);
            this.wumpacoinslabel.TabIndex = 13;
            this.wumpacoinslabel.Text = "0";
            // 
            // ohi
            // 
            this.ohi.AutoSize = true;
            this.ohi.Font = new System.Drawing.Font("Comic Sans MS", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ohi.ForeColor = System.Drawing.Color.Red;
            this.ohi.Location = new System.Drawing.Point(180, 184);
            this.ohi.Name = "ohi";
            this.ohi.Size = new System.Drawing.Size(95, 23);
            this.ohi.TabIndex = 14;
            this.ohi.Text = "Game over!";
            this.ohi.Visible = false;
            // 
            // restartbutton
            // 
            this.restartbutton.Location = new System.Drawing.Point(184, 210);
            this.restartbutton.Name = "restartbutton";
            this.restartbutton.Size = new System.Drawing.Size(75, 32);
            this.restartbutton.TabIndex = 15;
            this.restartbutton.Text = "Restart";
            this.restartbutton.UseVisualStyleBackColor = true;
            this.restartbutton.Visible = false;
            this.restartbutton.Click += new System.EventHandler(this.restartbutton_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Comic Sans MS", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.Color.Yellow;
            this.label1.Location = new System.Drawing.Point(12, 9);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(117, 23);
            this.label1.TabIndex = 16;
            this.label1.Text = "Wumpa Coins:";
            // 
            // The_Game
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.Gray;
            this.ClientSize = new System.Drawing.Size(441, 450);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.restartbutton);
            this.Controls.Add(this.ohi);
            this.Controls.Add(this.wumpacoinslabel);
            this.Controls.Add(this.wumpacoin3);
            this.Controls.Add(this.wumpacoin2);
            this.Controls.Add(this.wumpacoin1);
            this.Controls.Add(this.beakerbox);
            this.Controls.Add(this.nitrobox);
            this.Controls.Add(this.tntbox);
            this.Controls.Add(this.crashbandicoot);
            this.Controls.Add(this.pictureBox6);
            this.Controls.Add(this.pictureBox5);
            this.Controls.Add(this.pictureBox4);
            this.Controls.Add(this.pictureBox3);
            this.Controls.Add(this.pictureBox2);
            this.Controls.Add(this.pictureBox1);
            this.Name = "The_Game";
            this.Text = "The_Game";
            this.Load += new System.EventHandler(this.The_Game_Load);
            this.KeyDown += new System.Windows.Forms.KeyEventHandler(this.The_Game_KeyDown);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox4)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox5)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox6)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.crashbandicoot)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tntbox)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.nitrobox)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.beakerbox)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.wumpacoin1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.wumpacoin2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.wumpacoin3)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.PictureBox pictureBox2;
        private System.Windows.Forms.PictureBox pictureBox3;
        private System.Windows.Forms.PictureBox pictureBox4;
        private System.Windows.Forms.PictureBox pictureBox5;
        private System.Windows.Forms.PictureBox pictureBox6;
        private System.Windows.Forms.Timer timer1;
        private System.Windows.Forms.PictureBox crashbandicoot;
        private System.Windows.Forms.PictureBox tntbox;
        private System.Windows.Forms.PictureBox nitrobox;
        private System.Windows.Forms.PictureBox beakerbox;
        private System.Windows.Forms.PictureBox wumpacoin1;
        private System.Windows.Forms.PictureBox wumpacoin2;
        private System.Windows.Forms.PictureBox wumpacoin3;
        private System.Windows.Forms.Label wumpacoinslabel;
        private System.Windows.Forms.Label ohi;
        protected System.Windows.Forms.Button restartbutton;
        private System.Windows.Forms.Label label1;
    }
}
﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace CTRspinoff
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void aboutbutton_Click(object sender, EventArgs e)
        {
            About ab = new About();
            ab.Show();
            Visible = false;
        }

        private void playgamebutton_Click(object sender, EventArgs e)
        {
            Choose_A_Character cac = new Choose_A_Character();
            cac.Show();
            Visible = false;
        }

        private void button1_Click(object sender, EventArgs e)
        {
            Form2 help = new Form2();
            help.Show();
            Visible = false;
        }

        private void quitbutton_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}

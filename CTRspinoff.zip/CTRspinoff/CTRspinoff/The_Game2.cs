﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace CTRspinoff
{
    public partial class The_Game2 : Form
    {
        public The_Game2()
        {
            InitializeComponent();
        }

        private void The_Game2_Load(object sender, EventArgs e)
        {
            wumpacoinslabel.Text = MyGlobals.collectedwumpacoin.ToString();
        }

        private void pictureBox1_Click(object sender, EventArgs e)
        {

        }

        private void timer1_Tick(object sender, EventArgs e)
        {
            moveline(5);
            peliohi();
            wumpacoins(3);
            tnt(3);
            nitro(3);
            beaker(3);
            coincollection();
        }

        void moveline(int speed)
        {
            if (pictureBox1.Top >= 500)
            {
                pictureBox1.Top = 0;
            }
            else
            {
                pictureBox1.Top += speed;
            }

            if (pictureBox2.Top >= 500)
            {
                pictureBox2.Top = 0;
            }
            else
            {
                pictureBox2.Top += speed;
            }

            if (pictureBox3.Top >= 500)
            {
                pictureBox3.Top = 0;
            }
            else
            {
                pictureBox3.Top += speed;
            }

            if (pictureBox4.Top >= 500)
            {
                pictureBox4.Top = 0;
            }
            else
            {
                pictureBox4.Top += speed;
            }

            if (pictureBox5.Top >= 500)
            {
                pictureBox5.Top = 0;
            }
            else
            {
                pictureBox5.Top += speed;
            }
            if (pictureBox6.Top >= 500)
            {
                pictureBox6.Top = 0;
            }
            else
            {
                pictureBox6.Top += speed;
            }
        }

        private void The_Game2_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Left)
            {
                if (drneocortex.Left > 6)
                    drneocortex.Left += -20;
            }
            if (e.KeyCode == Keys.Right)
            {
                if (drneocortex.Right < 430)
                    drneocortex.Left += 20;
            }
        }

        public static class MyGlobals
        {
            public static int collectedwumpacoin;
        }

        Random rng = new Random();
        int x, y;
        void tnt(int speed)
        {
            if (tntbox.Top >= 500)
            {
                x = rng.Next(0, 394);
                tntbox.Location = new Point(x, 0);
            }
            else
            {
                tntbox.Top += speed;
            }
        }

        void nitro(int speed)
        {
            if (nitrobox.Top >= 500)
            {
                x = rng.Next(0, 394);
                nitrobox.Location = new Point(x, 0);
            }
            else
            {
                nitrobox.Top += speed;
            }
        }

        void beaker(int speed)
        {
            if (beakerbox.Top >= 500)
            {
                x = rng.Next(0, 394);
                beakerbox.Location = new Point(x, 0);
            }
            else
            {
                beakerbox.Top += speed;
            }
        }

        void wumpacoins(int speed)
        {
            if (wumpacoin1.Top >= 500)
            {
                x = rng.Next(0, 394);

                wumpacoin1.Location = new Point(x, 0);
            }
            else
            {
                wumpacoin1.Top += speed;
            }

            if (wumpacoin2.Top >= 500)
            {
                x = rng.Next(0, 394);

                wumpacoin2.Location = new Point(x, 0);
            }
            else
            {
                wumpacoin2.Top += speed;
            }

            if (wumpacoin3.Top >= 500)
            {
                x = rng.Next(0, 394);

                wumpacoin3.Location = new Point(x, 0);
            }
            else
            {
                wumpacoin3.Top += speed;
            }
        }

        void coincollection()
        {
            if (drneocortex.Bounds.IntersectsWith(wumpacoin1.Bounds))
            {
                MyGlobals.collectedwumpacoin = MyGlobals.collectedwumpacoin + 150;
                wumpacoinslabel.Text = MyGlobals.collectedwumpacoin.ToString();
                x = rng.Next(0, 394);
                wumpacoin1.Location = new Point(x, 0);
            }

            if (drneocortex.Bounds.IntersectsWith(wumpacoin2.Bounds))
            {
                MyGlobals.collectedwumpacoin = MyGlobals.collectedwumpacoin + 150;
                wumpacoinslabel.Text = MyGlobals.collectedwumpacoin.ToString();
                x = rng.Next(0, 394);
                wumpacoin2.Location = new Point(x, 0);
            }

            if (drneocortex.Bounds.IntersectsWith(wumpacoin3.Bounds))
            {
                MyGlobals.collectedwumpacoin = MyGlobals.collectedwumpacoin + 150;
                wumpacoinslabel.Text = MyGlobals.collectedwumpacoin.ToString();
                x = rng.Next(0, 394);
                wumpacoin3.Location = new Point(x, 0);
            }
        }

        void peliohi()
        {
            if (drneocortex.Bounds.IntersectsWith(tntbox.Bounds))
            {
                timer1.Enabled = false;
                ohi.Visible = true;
                restartbutton.Visible = true;
            }
            if (drneocortex.Bounds.IntersectsWith(nitrobox.Bounds))
            {
                timer1.Enabled = false;
                ohi.Visible = true;
                restartbutton.Visible = true;
            }
            if (drneocortex.Bounds.IntersectsWith(beakerbox.Bounds))
            {
                timer1.Enabled = false;
                ohi.Visible = true;
                restartbutton.Visible = true;
            }
        }

        private void restartbutton_Click(object sender, EventArgs e)
        {
            Application.Restart();
        }
    }
}

﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace CTRspinoff
{
    public partial class About : Form
    {
        public About()
        {
            InitializeComponent();
        }

        private void backbutton3_Click(object sender, EventArgs e)
        {
            Form f1 = new Form1();
            f1.Show();
            Visible = false;
        }
    }
}

﻿namespace CTRspinoff
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.textBox1 = new System.Windows.Forms.TextBox();
            this.playgamebutton = new System.Windows.Forms.Button();
            this.quitbutton = new System.Windows.Forms.Button();
            this.aboutbutton = new System.Windows.Forms.Button();
            this.button1 = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // textBox1
            // 
            this.textBox1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(0)))));
            this.textBox1.Font = new System.Drawing.Font("Racer", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox1.Location = new System.Drawing.Point(121, 23);
            this.textBox1.Name = "textBox1";
            this.textBox1.Size = new System.Drawing.Size(503, 30);
            this.textBox1.TabIndex = 0;
            this.textBox1.Text = "Crash Team Racing: the Spin-off";
            // 
            // playgamebutton
            // 
            this.playgamebutton.Font = new System.Drawing.Font("Racer", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.playgamebutton.Location = new System.Drawing.Point(307, 109);
            this.playgamebutton.Name = "playgamebutton";
            this.playgamebutton.Size = new System.Drawing.Size(142, 61);
            this.playgamebutton.TabIndex = 1;
            this.playgamebutton.Text = "Play game";
            this.playgamebutton.UseVisualStyleBackColor = true;
            this.playgamebutton.Click += new System.EventHandler(this.playgamebutton_Click);
            // 
            // quitbutton
            // 
            this.quitbutton.Font = new System.Drawing.Font("Racer", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.quitbutton.Location = new System.Drawing.Point(307, 384);
            this.quitbutton.Name = "quitbutton";
            this.quitbutton.Size = new System.Drawing.Size(142, 51);
            this.quitbutton.TabIndex = 2;
            this.quitbutton.Text = "Quit";
            this.quitbutton.UseVisualStyleBackColor = true;
            this.quitbutton.Click += new System.EventHandler(this.quitbutton_Click);
            // 
            // aboutbutton
            // 
            this.aboutbutton.Font = new System.Drawing.Font("Racer", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.aboutbutton.Location = new System.Drawing.Point(307, 301);
            this.aboutbutton.Name = "aboutbutton";
            this.aboutbutton.Size = new System.Drawing.Size(142, 51);
            this.aboutbutton.TabIndex = 3;
            this.aboutbutton.Text = "About";
            this.aboutbutton.UseVisualStyleBackColor = true;
            this.aboutbutton.Click += new System.EventHandler(this.aboutbutton_Click);
            // 
            // button1
            // 
            this.button1.Font = new System.Drawing.Font("Racer", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button1.Location = new System.Drawing.Point(307, 200);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(142, 58);
            this.button1.TabIndex = 4;
            this.button1.Text = "Help";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(0)))));
            this.ClientSize = new System.Drawing.Size(738, 447);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.aboutbutton);
            this.Controls.Add(this.quitbutton);
            this.Controls.Add(this.playgamebutton);
            this.Controls.Add(this.textBox1);
            this.Name = "Form1";
            this.Text = "Main Menu";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox textBox1;
        private System.Windows.Forms.Button playgamebutton;
        private System.Windows.Forms.Button quitbutton;
        private System.Windows.Forms.Button aboutbutton;
        private System.Windows.Forms.Button button1;
    }
}


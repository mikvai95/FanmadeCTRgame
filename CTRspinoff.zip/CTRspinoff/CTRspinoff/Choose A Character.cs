﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace CTRspinoff
{
    public partial class Choose_A_Character : Form
    {
        public Choose_A_Character()
        {
            InitializeComponent();
        }

        private void backbutton2_Click(object sender, EventArgs e)
        {
            Form1 f1 = new Form1();
            f1.Show();
            Visible = false;
        }

        private void cbbutton_Click(object sender, EventArgs e)
        {
            The_Game tg = new The_Game();
            tg.Show();
            Visible = false;
        }

        private void ncbutton_Click(object sender, EventArgs e)
        {
            The_Game2 tg2 = new The_Game2();
            tg2.Show();
            Visible = false;
        }
    }
}
